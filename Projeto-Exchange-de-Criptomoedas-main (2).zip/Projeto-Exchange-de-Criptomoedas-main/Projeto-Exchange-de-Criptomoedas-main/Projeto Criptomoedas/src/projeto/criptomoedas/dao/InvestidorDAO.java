package projeto.criptomoedas.dao;

import projeto.criptomoedas.model.Investidor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import projeto.criptomoedas.model.Carteira;

public class InvestidorDAO {

    public Investidor login(String cpf, String senha) {

        String sql = "SELECT * FROM investidor i "
           + "INNER JOIN carteira c ON i.id = c.id_investidor "
           + "WHERE i.cpf = ? AND i.senha = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement comando = conexao.prepareStatement(sql)) {

            comando.setString(1, cpf);
            comando.setString(2, senha);

            ResultSet resultado = comando.executeQuery();

            if (resultado.next()) {
                
                //recuperar dados pessoais
                String nome = resultado.getString("nome");
                String cpfEncontrado = resultado.getString("cpf");
                String senhaEncontrada = resultado.getString("senha");
                //recuperar saldos 
                double saldoReais = resultado.getDouble("saldo_reais");
                double saldoBitcoin = resultado.getDouble("saldo_bitcoins");
                double saldoEthereum = resultado.getDouble("saldo_ethereum");
                double saldoRipple = resultado.getDouble("saldo_ripple");
                
                //instanciar carteira
                Carteira carteira = new Carteira(
                    saldoReais,
                    saldoBitcoin,
                    saldoEthereum,
                    saldoRipple
                );
                //instanciar investidor
                Investidor investidor = new Investidor(
                    carteira,
                    nome,
                    cpfEncontrado,
                    senhaEncontrada
                );

                return investidor;
                
            } else {
                System.out.println("CPF ou senha invalidos!");
            }

        } catch (SQLException e) {
            System.out.println("Erro no login: " + e.getMessage());
        }

        return null;
    }
}
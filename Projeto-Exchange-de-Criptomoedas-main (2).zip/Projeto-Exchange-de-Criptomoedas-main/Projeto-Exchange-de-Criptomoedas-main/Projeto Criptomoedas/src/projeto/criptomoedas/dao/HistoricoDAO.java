package projeto.criptomoedas.dao;

import projeto.criptomoedas.model.Historico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import projeto.criptomoedas.model.Historico;
import java.util.List;
import java.util.ArrayList;
import java.sql.ResultSet;

public class HistoricoDAO {

    public void salvarHistorico(Historico historico, String cpf) {

        String sql = "INSERT INTO historico "
                + "(id_carteira, data, hora, valor, taxa, tipo, "
                + "saldo_reais, saldo_bitcoins, saldo_ethereum, saldo_ripple) "
                + "VALUES ((SELECT c.id FROM carteira c "
                + "INNER JOIN investidor i ON c.id_investidor = i.id "
                + "WHERE i.cpf = ?), ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement comando = conexao.prepareStatement(sql)) {

            comando.setString(1, cpf);
            comando.setDate(2, java.sql.Date.valueOf(historico.getData()));
            comando.setTime(3, java.sql.Time.valueOf(historico.getHorario()));
            comando.setDouble(4, historico.getValor());
            comando.setDouble(5, historico.getTaxa());
            comando.setString(6, historico.getTipo());
            comando.setDouble(7, historico.getSaldoReais());
            comando.setDouble(8, historico.getSaldoBitcoin());
            comando.setDouble(9, historico.getSaldoEthereum());
            comando.setDouble(10, historico.getSaldoRipple());

            comando.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao salvar histórico: " + e.getMessage());
        }
    }
    
    public List<Historico> consultarHistorico(String cpf) {

    List<Historico> historicos = new ArrayList<>();

    String sql = "SELECT h.* FROM historico h "
            + "INNER JOIN carteira c ON h.id_carteira = c.id "
            + "INNER JOIN investidor i ON c.id_investidor = i.id "
            + "WHERE i.cpf = ? "
            + "ORDER BY h.data DESC, h.hora DESC";

    try (Connection conexao = Conexao.conectar();
         PreparedStatement comando = conexao.prepareStatement(sql)) {

        comando.setString(1, cpf);

        ResultSet resultado = comando.executeQuery();

        while (resultado.next()) {

            Historico historico = new Historico(
                    resultado.getDate("data").toLocalDate(),
                    resultado.getTime("hora").toLocalTime(),
                    resultado.getDouble("valor"),
                    resultado.getDouble("taxa"),
                    resultado.getString("tipo"),
                    resultado.getDouble("saldo_reais"),
                    resultado.getDouble("saldo_bitcoins"),
                    resultado.getDouble("saldo_ethereum"),
                    resultado.getDouble("saldo_ripple")
            );

            historicos.add(historico);
        }

    } catch (SQLException e) {
        System.out.println("Erro ao consultar histórico: " + e.getMessage());
    }

    return historicos;
}
}
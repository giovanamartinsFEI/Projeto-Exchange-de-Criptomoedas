package projeto.criptomoedas.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    private static final String URL = "jdbc:postgresql://localhost:5432/projeto_criptomoedas";
    private static final String USUARIO = "postgres";
    private static final String SENHA = "6554";

    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }

    public static void testarConexao() {
        try {
            Connection conexao = conectar();
            System.out.println("Conexão com o banco realizada com sucesso!");
            conexao.close();
        } catch (SQLException e) {
            System.out.println("Erro na conexão: " + e.getMessage());
        }
    }
}
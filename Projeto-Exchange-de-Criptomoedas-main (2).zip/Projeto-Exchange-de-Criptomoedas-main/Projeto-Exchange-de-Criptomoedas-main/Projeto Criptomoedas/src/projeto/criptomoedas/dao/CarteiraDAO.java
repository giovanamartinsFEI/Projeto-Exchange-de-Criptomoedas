package projeto.criptomoedas.dao;

import projeto.criptomoedas.model.Carteira;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CarteiraDAO {

    public void atualizarSaldo(Carteira carteira, String cpf) {

        String sql = "UPDATE carteira SET saldo_reais = ?, "
                + "saldo_bitcoins = ?, "
                + "saldo_ethereum = ?, "
                + "saldo_ripple = ? "
                + "WHERE id_investidor = "
                + "(SELECT id FROM investidor WHERE cpf = ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement comando = conexao.prepareStatement(sql)) {

            comando.setDouble(1, carteira.getSaldoReais());
            comando.setDouble(2, carteira.getSaldoBitcoins());
            comando.setDouble(3, carteira.getSaldoEthereum());
            comando.setDouble(4, carteira.getSaldoRipple());
            comando.setString(5, cpf);

            comando.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar saldo: " + e.getMessage());
        }
    }
}
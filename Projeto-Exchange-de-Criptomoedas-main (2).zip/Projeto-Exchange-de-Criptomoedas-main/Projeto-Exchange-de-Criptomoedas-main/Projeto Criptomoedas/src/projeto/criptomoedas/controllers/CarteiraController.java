
package projeto.criptomoedas.controllers;

import projeto.criptomoedas.model.Investidor;
import projeto.criptomoedas.model.Carteira;
import projeto.criptomoedas.dao.CarteiraDAO;

public class CarteiraController {

    private Carteira carteira;
    private Investidor investidor;

    public CarteiraController(Investidor investidor) {
        this.investidor = investidor;
        this.carteira = investidor.getCarteira();
    }

    // ATUALIZAR SALDO NO BANCO
    private void atualizarBanco() {
        CarteiraDAO dao = new CarteiraDAO();
        dao.atualizarSaldo(carteira, investidor.getCpf());
    }

    // DEPÓSITO
    public boolean depositar(double valor) {

        if (valor <= 0) {
            return false;
        }

        carteira.depositar(valor);
        atualizarBanco();
        return true;
    }

    // SAQUE
    public int sacar(double valor) {

        if (valor <= 0) {
            return 0;
        }

        if (valor > carteira.getSaldoReais()) {
            return -1;
        }

        carteira.sacar(valor);
        atualizarBanco();
        return 1;
    }

    // CONSULTAR SALDOS
    public double getSaldoReais() {
        return carteira.getSaldoReais();
    }

    public double getSaldoBitcoin() {
        return carteira.getSaldoBitcoins();
    }

    public double getSaldoEthereum() {
        return carteira.getSaldoEthereum();
    }

    public double getSaldoRipple() {
        return carteira.getSaldoRipple();
    }

    // CONSULTAR COTAÇÕES
    public double getCotacaoBitcoin() {
        return carteira.getCotacaoBitcoin();
    }

    public double getCotacaoEthereum() {
        return carteira.getCotacaoEthereum();
    }

    public double getCotacaoRipple() {
        return carteira.getCotacaoRipple();
    }

    // COMPRAR BITCOIN
    public int comprarBitcoin(double valor) {

        if (valor <= 0) {
            return 0;
        }

        if (valor > carteira.getSaldoReais()) {
            return -1;
        }

        carteira.comprarBit(valor);
        atualizarBanco();
        return 1;
    }

    // COMPRAR ETHEREUM
    public int comprarEthereum(double valor) {

        if (valor <= 0) {
            return 0;
        }

        if (valor > carteira.getSaldoReais()) {
            return -1;
        }

        carteira.comprarEthereum(valor);
        atualizarBanco();
        return 1;
    }

    // COMPRAR RIPPLE
    public int comprarRipple(double valor) {

        if (valor <= 0) {
            return 0;
        }

        if (valor > carteira.getSaldoReais()) {
            return -1;
        }

        carteira.comprarRipple(valor);
        atualizarBanco();
        return 1;
    }

    
    // VENDER BITCOIN
    public int venderBitcoin(double valor) {

        if (valor <= 0) {
            return 0;
        }

        double quantidade = valor / carteira.getCotacaoBitcoin();

        if (quantidade > carteira.getSaldoBitcoins()) {
            return -1;
        }

        carteira.venderBit(quantidade);
        atualizarBanco();
        return 1;
    }

    // VENDER ETHEREUM
    public int venderEthereum(double valor) {

        if (valor <= 0) {
            return 0;
        }

        double quantidade = valor / carteira.getCotacaoEthereum();

        if (quantidade > carteira.getSaldoEthereum()) {
            return -1;
        }

        carteira.venderEthereum(quantidade);
        atualizarBanco();
        return 1;
    }

    // VENDER RIPPLE
    public int venderRipple(double valor) {

        if (valor <= 0) {
            return 0;
        }

        double quantidade = valor / carteira.getCotacaoRipple();

        if (quantidade > carteira.getSaldoRipple()) {
            return -1;
        }

        carteira.venderRipple(quantidade);
        atualizarBanco();
        return 1;
    }

}


package projeto.criptomoedas.controllers;

import java.util.List;
import java.util.Locale;
import java.time.format.DateTimeFormatter;

import projeto.criptomoedas.dao.HistoricoDAO;
import projeto.criptomoedas.model.Historico;
import projeto.criptomoedas.model.Investidor;

public class ExtratoController {

    public String gerarExtrato(Investidor investidor) {

        StringBuilder extrato = new StringBuilder();

        extrato.append("Nome: ").append(investidor.getNome()).append("\n");
        extrato.append("CPF: ").append(investidor.getCpf()).append("\n\n");

        HistoricoDAO dao = new HistoricoDAO();

        List<Historico> historicos = dao.consultarHistorico(investidor.getCpf());

        if (historicos == null || historicos.isEmpty()) {
            extrato.append("Nenhuma operação encontrada.");
            return extrato.toString();
        }

        DateTimeFormatter formatoData =
                DateTimeFormatter.ofPattern("dd-MM-yyyy");

        DateTimeFormatter formatoHora =
                DateTimeFormatter.ofPattern("HH:mm");

        for (Historico h : historicos) {

            extrato.append(h.getData().format(formatoData))
                   .append(" ")
                   .append(h.getHorario().format(formatoHora))
                   .append(" | ")
                   .append(h.getTipo())
                   .append(" | VALOR: ")
                   .append(String.format(Locale.US, "%.2f", h.getValor()))
                   .append(" | CT: --")
                   .append(" | TX: ")
                   .append(String.format(Locale.US, "%.2f", h.getTaxa()))
                   .append(" | REAL: ")
                   .append(String.format(Locale.US, "%.2f", h.getSaldoReais()))
                   .append(" | BTC: ")
                   .append(String.format(Locale.US, "%.8f", h.getSaldoBitcoin()))
                   .append(" | ETH: ")
                   .append(String.format(Locale.US, "%.8f", h.getSaldoEthereum()))
                   .append(" | XRP: ")
                   .append(String.format(Locale.US, "%.8f", h.getSaldoRipple()))
                   .append("\n");
        }

        return extrato.toString();
    }
}

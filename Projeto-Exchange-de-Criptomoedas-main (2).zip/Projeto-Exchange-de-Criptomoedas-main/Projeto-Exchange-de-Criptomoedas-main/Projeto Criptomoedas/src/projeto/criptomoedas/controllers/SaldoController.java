package projeto.criptomoedas.controllers;

import projeto.criptomoedas.model.Investidor;

public class SaldoController {

    private Investidor investidor;

    public SaldoController(Investidor investidor) {
        this.investidor = investidor;
    }

    public String getNome() {
        return investidor.getNome();
    }

    public String getCpf() {
        return investidor.getCpf();
    }

    public double getSaldoReais() {
        return investidor.getCarteira().getSaldoReais();
    }

    public double getSaldoBitcoin() {
        return investidor.getCarteira().getSaldoBitcoins();
    }

    public double getSaldoEthereum() {
        return investidor.getCarteira().getSaldoEthereum();
    }

    public double getSaldoRipple() {
        return investidor.getCarteira().getSaldoRipple();
    }
}
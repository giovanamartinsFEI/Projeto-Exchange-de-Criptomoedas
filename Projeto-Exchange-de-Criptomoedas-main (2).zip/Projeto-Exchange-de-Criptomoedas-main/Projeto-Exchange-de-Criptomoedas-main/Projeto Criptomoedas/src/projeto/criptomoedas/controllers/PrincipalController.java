/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto.criptomoedas.controllers;

import projeto.criptomoedas.model.Investidor;

/**
 *
 * @author giova
 */
public class PrincipalController {
    
    private Investidor investidor;

    public PrincipalController(Investidor investidor) {
        this.investidor = investidor;
    }

    public void atualizarCotacoes() {
        investidor.getCarteira().atualizarCotacoes();
    }

    public double getCotacaoBitcoin() {
        return investidor.getCarteira().getCotacaoBitcoin();
    }

    public double getCotacaoEthereum() {
        return investidor.getCarteira().getCotacaoEthereum();
    }

    public double getCotacaoRipple() {
        return investidor.getCarteira().getCotacaoRipple();
    }
}
    


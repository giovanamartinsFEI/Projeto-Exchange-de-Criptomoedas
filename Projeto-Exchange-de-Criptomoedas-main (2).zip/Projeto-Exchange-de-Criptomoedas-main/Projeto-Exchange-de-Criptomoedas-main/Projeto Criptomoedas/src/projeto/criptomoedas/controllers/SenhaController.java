
package projeto.criptomoedas.controllers;

import javax.swing.JFrame;
import projeto.criptomoedas.model.Investidor;
import projeto.criptomoedas.views.TelaExtrato;
import projeto.criptomoedas.views.TelaSaldo;
import projeto.criptomoedas.views.TelaCompra;
import projeto.criptomoedas.views.TelaVender;

public class SenhaController {

    public JFrame confirmarSenha(Investidor investidor, String senha, String operacao) {

        if (senha.equals(investidor.getSenha())) {

            if (operacao.equals("saldo")) {
                return new TelaSaldo(investidor);
            }
            else if (operacao.equals("extrato")) {
                return new TelaExtrato(investidor);
            }
            else if (operacao.equals("comprar")) {
                return new TelaCompra(investidor);
            }
            else if (operacao.equals("vender")) {
                return new TelaVender(investidor);
            }
        }

        return null;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto.criptomoedas.controllers;

import projeto.criptomoedas.dao.InvestidorDAO;
import projeto.criptomoedas.model.Investidor;
/**
 *
 * @author giova
 */
public class LoginController {

    public Investidor realizarLogin(String cpf, String senha) {

        InvestidorDAO dao = new InvestidorDAO();

        return dao.login(cpf, senha);
    }
}


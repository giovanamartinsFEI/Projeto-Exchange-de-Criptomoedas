
package projeto.criptomoedas.model;

import java.util.ArrayList;
import java.util.List;
import projeto.criptomoedas.dao.HistoricoDAO;

public class Carteira {
    protected double saldoReais, saldoBitcoins, saldoEthereum, saldoRipple;
    protected Moeda bitCoin ;
    protected Moeda ethereum ;
    protected Moeda ripple ;
    private String cpfInvestidor;
    private List<Historico> historicos = new ArrayList<>();
    
    public List<Historico> getHistoricos() {
    return historicos;
    }   

    public double getSaldoReais() {
        return saldoReais;
    }

    public void setSaldoReais(double saldoReais) {
        this.saldoReais = saldoReais;
    }

    public double getSaldoBitcoins() {
        return saldoBitcoins;
    }

    public void setSaldoBitcoins(double saldoBitcoins) {
        this.saldoBitcoins = saldoBitcoins;
    }

    public double getSaldoEthereum() {
        return saldoEthereum;
    }

    public void setSaldoEthereum(double saldoEthereum) {
        this.saldoEthereum = saldoEthereum;
    }

    public double getSaldoRipple() {
        return saldoRipple;
    }

    public void setSaldoRipple(double saldoRipple) {
        this.saldoRipple = saldoRipple;
    }

    public Carteira(double saldoReais, double saldoBitcoins, 
            double saldoEthereum, double saldoRipple) {
        this.saldoReais = saldoReais;
        this.saldoBitcoins = saldoBitcoins;
        this.saldoEthereum = saldoEthereum;
        this.saldoRipple = saldoRipple;
        
        bitCoin = new Moeda("BitCoin", "BTC", 350000000);
        ethereum = new Moeda("Ethereum", "ETH", 12500);
        ripple = new Moeda("Ripple", "XRP", 7.0);

                
    }
    
    public void setCpfInvestidor(String cpfInvestidor) {
        this.cpfInvestidor = cpfInvestidor;
    }
    
    //deposito de saque em reais, o valor deve ser maior que zero
    public void depositar (double valor){
        if(valor > 0){
            saldoReais = valor + saldoReais;
            
            registrarHistorico(valor, 0.0, "Depósito");
            
            System.out.println("Valor depositado com sucesso!");
        }
        else{
            System.out.println("Valor invalido");
        }
    }
    
    
    //saque de saldo em reais; condições: se o valor for 0 ou negativo e se o 
    //valor for maior que o saldo em reais
    
    public void sacar (double valor){
        if(valor <= 0){
            System.out.println("O valor do saque deve ser maior que zero!");
        }
        
        else if(valor > saldoReais){
            System.out.println("Saldo da conta é insuficiente!");
        }
        else {
            saldoReais = saldoReais - valor;
            
            registrarHistorico(-valor, 0.0, "saque");

            System.out.println("Valor sacado com sucesso!");       
        }   
    }
    
    
    //////////////////////////FASE DE COMPRAS DE CRIPTOMOEDAS/////////////////
    /// @param valor/
    
    //compra Bitcoins
    
    public void comprarBit(double valor){
        //variaveis locais
        double valorAposTaxa, taxa, quantidadeBitCoin;
        
        if(valor <= 0){
            System.out.println("O valor para compra deve ser maior que zero!");    
        }
        
        else if(valor > saldoReais){
            System.out.println("Saldo insuficiente, insira um valor menor!");       
        }
        
        else{
            valorAposTaxa = valor - (valor * 0.02);
            taxa = valor - valorAposTaxa;
            quantidadeBitCoin = valorAposTaxa / bitCoin.getCotacao();
            saldoReais = saldoReais - valor;
            saldoBitcoins = saldoBitcoins + quantidadeBitCoin;
            registrarHistorico(-valor, valor * 0.02, "Compra BTC");

                System.out.printf("Valor inserido: R$ %.2f%n" + "Taxa de Compra:"
                        + " R$ %.2f%n" +"Valor Após Taxa: R$ %.2f%n" +
                        "Quantidade de Bitcoin Adquirida: %.8f BTC%n",
                        valor, taxa, valorAposTaxa, quantidadeBitCoin);
        }   
    }
    
    //Compra Ethereum
    
    public void comprarEthereum(double valor){
        //variaveis locais
        double valorAposTaxa, taxa, quantidadeEthereum;

        if(valor <= 0){
            System.out.println("O valor para compra deve ser maior que zero!");    
        }

        else if(valor > saldoReais){
            System.out.println("Saldo insuficiente, insira um valor menor!");       
        }

        else{
            valorAposTaxa = valor - (valor * 0.01);
            taxa = valor - valorAposTaxa;
            quantidadeEthereum = valorAposTaxa / ethereum.getCotacao();
            saldoReais = saldoReais - valor;
            saldoEthereum = saldoEthereum + quantidadeEthereum;
            registrarHistorico(-valor, valor * 0.01, "Compra ETH");

                System.out.printf("Valor inserido: R$ %.2f%n" + "Taxa de Compra:"
                        + " R$ %.2f%n" +"Valor Após Taxa: R$ %.2f%n" +
                        "Quantidade de Ethereum Adquirida: %.8f ETH%n",
                        valor, taxa, valorAposTaxa, quantidadeEthereum);
        }
    }
    
    //Compra Ripple
    
    public void comprarRipple(double valor){
    //variaveis locais
    double valorAposTaxa, taxa, quantidadeRipple;

        if(valor <= 0){
            System.out.println("O valor para compra deve ser maior que zero!");    
        }

        else if(valor > saldoReais){
            System.out.println("Saldo insuficiente, insira um valor menor!");       
        }

        else{
            valorAposTaxa = valor - (valor * 0.01);
            taxa = valor - valorAposTaxa;
            quantidadeRipple = valorAposTaxa / ripple.getCotacao();
            saldoReais = saldoReais - valor;
            saldoRipple = saldoRipple + quantidadeRipple;
            registrarHistorico(-valor, valor * 0.01, "Compra XRP");

                System.out.printf("Valor inserido: R$ %.2f%n" + "Taxa de Compra:"
                        + " R$ %.2f%n" +"Valor Após Taxa: R$ %.2f%n" +
                        "Quantidade de Ripple Adquirida: %.8f XRP%n",
                        valor, taxa, valorAposTaxa, quantidadeRipple);

        }
    }
    
    ////////////////////////FASE DE VENDA DE CRIPTOMOEDAS/////////////////////
    /// @param valor/
    
    //venda Bitcoin
    public void venderBit(double valor){
        //variaveis locais
        double valorAposTaxa, taxa, quantidadeReais;
        
        if(valor <= 0){
            System.out.println("O valor para venda deve ser maior que zero!");    
        }
        
        else if(valor > saldoBitcoins){
            System.out.println("Saldo de BitCoins insuficiente, insira um valor menor!");       
        }
        
        else{
            quantidadeReais = valor * bitCoin.getCotacao();
            valorAposTaxa = quantidadeReais - (quantidadeReais * 0.03);
            taxa = quantidadeReais - valorAposTaxa;
            saldoReais = saldoReais + valorAposTaxa;
            saldoBitcoins = saldoBitcoins - valor;
            registrarHistorico(valor * bitCoin.getCotacao(), valor * 
                    bitCoin.getCotacao() * 0.03, "Venda BTC");
                System.out.printf("Valor inserido de BitCoins: %.8f%n" + "Taxa de venda:"
                        + " R$ %.2f%n" +"Valor em reais: R$ %.2f%n" +
                        "Valor recebido após taxa: R$ %.2f%n",
                        valor, taxa, quantidadeReais, valorAposTaxa);
        }   
    }
    
    //venda Ethereum
    public void venderEthereum(double valor){
        //variaveis locais
        double valorAposTaxa, taxa, quantidadeReais;
        
        if(valor <= 0){
            System.out.println("O valor para venda deve ser maior que zero!");    
        }
        
        else if(valor > saldoEthereum){
            System.out.println("Saldo de Ethereums insuficiente, insira um valor menor!");       
        }
        
        else{
            quantidadeReais = valor * ethereum.getCotacao();
            valorAposTaxa = quantidadeReais - (quantidadeReais * 0.02);
            taxa = quantidadeReais - valorAposTaxa;
            saldoReais = saldoReais + valorAposTaxa;
            saldoEthereum = saldoEthereum - valor;
            registrarHistorico(valor * ethereum.getCotacao(), valor *
                    ethereum.getCotacao() * 0.02, "Venda ETH");
                System.out.printf("Valor inserido de Ethereum: %.8f%n" + "Taxa de venda:"
                        + " R$ %.2f%n" +"Valor em reais: R$ %.2f%n" +
                        "Valor recebido após taxa: R$ %.2f%n",
                        valor, taxa, quantidadeReais, valorAposTaxa);
        }   
    }
    
    //venda Ripple
    
    public void venderRipple(double valor){
        //variaveis locais
        double valorAposTaxa, taxa, quantidadeReais;
        
        if(valor <= 0){
            System.out.println("O valor para venda deve ser maior que zero!");    
        }
        
        else if(valor > saldoRipple){
            System.out.println("Saldo de Ripples insuficiente, insira um valor menor!");       
        }
        
        else{
            quantidadeReais = valor * ripple.getCotacao();
            valorAposTaxa = quantidadeReais - (quantidadeReais * 0.01);
            taxa = quantidadeReais - valorAposTaxa;
            saldoReais = saldoReais + valorAposTaxa;
            saldoRipple = saldoRipple - valor;
            registrarHistorico(valor * ripple.getCotacao(), valor *
                    ripple.getCotacao() * 0.01, "Venda XRP");
                System.out.printf("Valor inserido de Ripples: %.8f%n" + "Taxa de venda:"
                        + " R$ %.2f%n" +"Valor em reais: R$ %.2f%n" +
                        "Valor recebido após taxa: R$ %.2f%n",
                        valor, taxa, quantidadeReais, valorAposTaxa);
        }   
    }
    
    public void consultarSaldo(){
    System.out.printf("Saldo Reais: R$ %.2f%n" + "Saldo BitCoin:"
                        + " %.8f%n" +"Saldo Ethereum: %.2f%n" +
                        "Saldo Ripple: %.2f%n",
                        saldoReais, saldoBitcoins, saldoEthereum, saldoRipple);
    }   
    
    public void registrarHistorico(double valor, double taxa, String tipo) {
        Historico registro = new Historico(
            java.time.LocalDate.now(),
            java.time.LocalTime.now(),
            valor,
            taxa,
            tipo,
            saldoReais,
            saldoBitcoins,
            saldoEthereum,
            saldoRipple
        );

        historicos.add(registro);
        HistoricoDAO dao = new HistoricoDAO();
        dao.salvarHistorico(registro, cpfInvestidor);
    }  
    
    //visualização da cotação na tela principal GUI e atualização
    
    public void atualizarCotacoes() {
        bitCoin.atualizarCotacao();
        ethereum.atualizarCotacao();
        ripple.atualizarCotacao();
    }
    
    public double getCotacaoBitcoin() {
        return bitCoin.getCotacao();
    }

    public double getCotacaoEthereum() {
        return ethereum.getCotacao();
    }

    public double getCotacaoRipple() {
        return ripple.getCotacao();
    }
}



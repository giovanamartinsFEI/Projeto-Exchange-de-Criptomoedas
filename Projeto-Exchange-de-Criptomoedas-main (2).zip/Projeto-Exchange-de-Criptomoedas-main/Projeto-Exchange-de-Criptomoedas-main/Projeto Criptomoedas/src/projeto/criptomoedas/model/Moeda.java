
package projeto.criptomoedas.model;

import java.util.Random;

public class Moeda {
    protected String nome, sigla;
    protected double cotacao;

    public Moeda(String nome, String sigla, double cotacao) {
        this.nome = nome;
        this.sigla = sigla;
        this.cotacao = cotacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public double getCotacao() {
        return cotacao;
    }

    public void setCotacao(double cotacao) {
        this.cotacao = cotacao;
    }
    
    public void atualizarCotacao(){
        double novaCotacao, variacao;
        
        Random random = new Random();
        
        variacao = (random.nextDouble() * 0.10) - 0.05;
        
        novaCotacao = cotacao * (1 + variacao);
        cotacao = novaCotacao;
    
    
    
    }
    
}

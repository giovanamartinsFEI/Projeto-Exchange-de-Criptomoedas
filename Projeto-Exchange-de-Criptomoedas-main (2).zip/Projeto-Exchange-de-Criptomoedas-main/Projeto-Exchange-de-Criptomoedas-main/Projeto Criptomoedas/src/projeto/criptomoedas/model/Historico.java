
package projeto.criptomoedas.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Historico {
    
    //organização de atributos da tabela visual
    private LocalDate data;
    private LocalTime horario;
    private double valor, taxa;
    private String tipo;
    
    //valores
    private double saldoReais, saldoBitcoin, saldoEthereum, saldoRipple;

    public Historico(LocalDate data, LocalTime horario, double valor, double taxa,
            String tipo, double saldoReais, double saldoBitcoin, 
            double saldoEthereum, double saldoRipple) {
        this.data = data;
        this.horario = horario;
        this.valor = valor;
        this.taxa = taxa;
        this.tipo = tipo;
        this.saldoReais = saldoReais;
        this.saldoBitcoin = saldoBitcoin;
        this.saldoEthereum = saldoEthereum;
        this.saldoRipple = saldoRipple;
    }

    public LocalDate getData() {
        return data;
    }

    public LocalTime getHorario() {
        return horario;
    }

    public double getValor() {
        return valor;
    }

    public double getTaxa() {
        return taxa;
    }

    public String getTipo() {
        return tipo;
    }

    public double getSaldoReais() {
        return saldoReais;
    }

    public double getSaldoBitcoin() {
        return saldoBitcoin;
    }

    public double getSaldoEthereum() {
        return saldoEthereum;
    }

    public double getSaldoRipple() {
        return saldoRipple;
    }
    
}
